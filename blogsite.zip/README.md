# Django Blog Application

Slightly advanced blog application built with Django (authentication, categories, comments, CRUD for posts).

## Features
- User signup / login / logout
- Create / edit / delete posts (authors only)
- Categories for posts
- Comment on posts (logged-in users)
- SQLite (default DB)

## Setup (local)
1. Install Python (3.8+).
2. Create virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run migrations and create superuser:
   ```bash
   python manage.py migrate
   python manage.py createsuperuser
   ```
5. Run server:
   ```bash
   python manage.py runserver
   ```
6. Open http://127.0.0.1:8000/

## Notes for GitHub
- Add a descriptive repo README (this file is a starting point).
- You can include screenshots under `/static/images/` if you want.
- To push to GitHub:
  ```bash
  git init
  git add .
  git commit -m "Initial commit - Django blog"
  git branch -M main
  git remote add origin <your-github-repo-url>
  git push -u origin main
  ```

## Customize
- Change `SECRET_KEY` in `blogsite/settings.py` for production.
- Set `DEBUG=False` and configure `ALLOWED_HOSTS` before deploying.

Good luck — let me know if you want Docker support or CI setup!
